<?php

$config = array(
	'Application' => array(
		'name' 	  => 'CakeStrap',
		'version' => 'v0.7',
		'status'  => 1,
		'maintenance' => 0
	),
	'Meta' => array(
		'title' 	  => 'YETI POLYCHEM MIS SYSTEM',
		'description' => '',
		'keywords' 	  => 'polychem',
	),
	
	'Google' => array(
		'analytics'  => '',
	),
	
	'Email' => array(
		'from_email' => array('{{from_name}}' => '{{from_email}}'),
		'contact_mail' => array('{{contact_name}}' => '{{contact_mail}}')
	)
);

?>
