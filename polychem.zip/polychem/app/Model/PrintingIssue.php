<?php
App::uses('AppModel', 'Model');
/**
 * PrintingIssue Model
 *
 */
class PrintingIssue extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'printing_issue';

}
