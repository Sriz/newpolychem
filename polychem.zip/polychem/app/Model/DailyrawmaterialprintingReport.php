<?php
App::uses('AppModel', 'Model');
/**
 * DailyrawmaterialprintingReport Model
 *
 */
class DailyrawmaterialprintingReport extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'dailyrawmaterialprinting_report';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'cyclo';

}
