<?php
App::uses('AppModel', 'Model');
/**
 * TimelossReason Model
 *
 */
class TimelossReason extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'timeloss_reason';

}
