<?php
App::uses('AppModel', 'Model');
/**
 * PurchaseStock Model
 *
 */
class PurchaseStock extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'purchaseStock';

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'y';

}
