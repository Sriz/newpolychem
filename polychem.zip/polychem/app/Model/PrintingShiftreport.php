<?php
App::uses('AppModel', 'Model');
/**
 * PrintingShiftreport Model
 *
 */
class PrintingShiftreport extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'printing_shiftreport';

}
