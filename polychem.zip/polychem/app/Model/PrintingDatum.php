<?php
App::uses('AppModel', 'Model');
/**
 * PrintingDatum Model
 *
 */
class PrintingDatum extends AppModel {

}
