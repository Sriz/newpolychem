<?php
App::uses('AppModel', 'Model');
/**
 * CalenderScrap Model
 *
 */
class CalenderScrap extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'calender_scrap';

}
