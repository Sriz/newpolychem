<?php
App::uses('AppModel', 'Model');
/**
 * LaminatingReasonOther Model
 *
 */
class LaminatingReasonOther extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'laminating_reason_other';

}
