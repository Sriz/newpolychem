<?php
App::uses('AppModel', 'Model');
/**
 * MixingMaterial Model
 *
 */
class MixingMaterial extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

}
