<?php
App::uses('AppModel', 'Model');
/**
 * CalenderInput Model
 *
 */
class CalenderInput extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'calender_input';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'total_input';

}
